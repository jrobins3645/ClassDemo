//
//  SuperCookDemo.swift
//  ClassDemo
//
//  Created by Jeff on 5/9/23.
//

import SwiftUI

struct SuperCookDemo: View {
    var body: some View {
        VStack (alignment: .leading) {
            Image("Food")
            Text("Fried Rice Recipe")
                .font(.system(size: 36))
                .fontWeight(.bold)
            
            HStack {
                Text("Cooking Time:")
                    .fontWeight(.bold)
                Text("30 min")
            }
            Divider()
            
            Text("Ingredients")
                .font(.title)
                .fontWeight(.bold)
            HStack {
                Circle()
                    .frame(width: 5.0)
                Text("oil-3tbsp")
            }
            HStack {
                Circle()
                    .frame(width: 5.0)
                Text("oil-3tbsp")
            }
            
            
            
            Spacer()
        }
        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
    }
}

struct SuperCookDemo_Previews: PreviewProvider {
    static var previews: some View {
        SuperCookDemo()
    }
}
